<?php
session_start();
include("includes/config.php");
include("includes/auth_check.php");

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Fetch data for dashboard overview
$totalChildren = $conn->query("SELECT COUNT(*) AS total FROM children")->fetch_assoc()['total'];
$pendingAdoptions = $conn->query("SELECT COUNT(*) AS total FROM adoptions WHERE status='Pending'")->fetch_assoc()['total'];
$completedAdoptions = $conn->query("SELECT COUNT(*) AS total FROM adoptions WHERE status='Approved'")->fetch_assoc()['total'];
$totalUsers = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
?>

<?php include("includes/header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Orphanage System</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: Arial, sans-serif;
    }

    .dashboard-container {
      max-width: 1100px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      color: #333;
    }

    .navbar {
      background: #f1f1f1;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 25px;
    }

    .navbar a {
      margin: 0 15px;
      text-decoration: none;
      font-weight: bold;
      color: #2a9d8f;
      transition: color 0.3s;
    }

    .navbar a:hover {
      color: #21867a;
    }

    .navbar .logout {
      color: red;
    }

    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 25px;
    }

    .card {
      background: #fff;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      text-align: center;
      font-size: 18px;
      color: #333;
      transition: transform 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card h3 {
      color: #2a9d8f;
      font-size: 22px;
      margin-bottom: 10px;
    }

    footer {
      text-align: center;
      padding: 15px;
      background: #f1f1f1;
      margin-top: 40px;
      border-radius: 10px;
    }
  </style>
</head>
<body>

<div class="dashboard-container">
 <h1>
  Welcome Admin, 
  <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?> 👋
</h1>


  <div class="navbar">
    <a href="add_child.php">➕ Add Child</a>
    <a href="manage_adoption.php">👶 Manage Adoption</a>
    <a href="child_track.php">📍 Track Child</a>
    <a href="view_users.php">👥 View Users</a>
    <a href="add_tracking.php">👥 Update Tracking</a>
    <a href="logout.php" class="logout">🚪 Logout</a>
  </div>

  <div class="dashboard-grid">
    <div class="card">
      <h3>👶 Total Children</h3>
      <p><?php echo $totalChildren; ?></p>
    </div>
    <div class="card">
      <h3>❤️ Pending Adoptions</h3>
      <p><?php echo $pendingAdoptions; ?></p>
    </div>
    <div class="card">
      <h3>✅ Completed Adoptions</h3>
      <p><?php echo $completedAdoptions; ?></p>
    </div>
    <div class="card">
      <h3>👥 Total Users</h3>
      <p><?php echo $totalUsers; ?></p>
    </div>
  </div>
</div>

<?php include("includes/footer.php"); ?>

</body>
</html>
