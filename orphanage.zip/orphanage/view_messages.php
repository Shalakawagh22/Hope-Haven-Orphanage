<?php
include 'includes/config.php';
include 'includes/header.php';

// Simple listing of contact messages
$res = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
?>

<div class="container">
  <h2>Contact Messages</h2>
  <table class="data-table">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Message</th><th>When</th></tr></thead>
    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= htmlspecialchars($row['user_name']) ?></td>
          <td><?= htmlspecialchars($row['email']) ?></td>
          <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
          <td><?= $row['created_at'] ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php include 'includes/footer.php'; ?>
