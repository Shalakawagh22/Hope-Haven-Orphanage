<?php
session_start();
include 'includes/config.php';
include 'includes/header.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    if (!empty($email)) {
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Generate unique token and expiry (valid 30 mins)
            $token = bin2hex(random_bytes(16));
            $expiry = date("Y-m-d H:i:s", strtotime("+30 minutes"));

            // Store token in DB
            
            $update = "UPDATE users SET reset_token=?, token_expiry=? WHERE email=?";
            $stmt2 = $conn->prepare($update);
            $stmt2->bind_param("sss", $token, $expiry, $email);
            $stmt2->execute();

            // Send mail
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'shalakawagh22@gmail.com';
                $mail->Password   = 'naxb ycnd xtvz upce'; // Your Gmail App Password
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                $mail->setFrom('shalakawagh22@gmail.com', 'Hope Haven');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Hope Haven - Password Reset';
                $resetLink = "http://localhost/orphanage/reset_password.php?token=$token";
                $mail->Body = "Click here to reset your password: <a href='$resetLink'>$resetLink</a><br>This link expires in 30 minutes.";

                $mail->send();
                $message = "<p style='color:green;'>Password reset link sent to your registered email.</p>";
            } catch (Exception $e) {
                $message = "<p style='color:red;'>Mailer Error: {$mail->ErrorInfo}</p>";
            }
        } else {
            $message = "<p style='color:red;'>Email not found.</p>";
        }
    } else {
        $message = "<p style='color:red;'>Please enter your email address.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>
<link rel="stylesheet" href="css/style.css">
<style>
body {background: #f5f7fa; font-family: 'Segoe UI';}
.forgot-container {display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:70vh;}
.forgot-box {background:#fff;padding:30px 40px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.1);text-align:center;width:380px;}
.forgot-box h2{color:#ff7043;margin-bottom:20px;}
.forgot-box input{width:100%;padding:10px;margin:10px 0;border-radius:8px;border:1px solid #ccc;}
.forgot-box button{width:100%;background:#ff7043;color:white;border:none;padding:10px;border-radius:8px;cursor:pointer;font-size:16px;}
.forgot-box button:hover{background:#ff5722;}
.forgot-box a{display:block;margin-top:15px;color:#ff7043;text-decoration:none;}
.forgot-box a:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="forgot-container">
<div class="forgot-box">
<h2>Forgot Password</h2>
<form method="POST" action="">
<input type="email" name="email" placeholder="Enter your registered email" required>
<button type="submit">Send Reset Link</button>
</form>
<div class="message"><?= $message; ?></div>
<a href="login.php">Back to Login</a>
</div>
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
