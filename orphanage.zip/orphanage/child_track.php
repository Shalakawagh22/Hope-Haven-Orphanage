<?php
include 'includes/config.php';
include 'includes/auth_check.php';

$result = $conn->query("SELECT c.name, t.location, t.update_time, t.note 
                        FROM child_tracking t 
                        JOIN children c ON c.id = t.child_id 
                        ORDER BY t.update_time DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Child Tracking Dashboard</title>
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f5f7fa;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 900px;
      margin: 60px auto;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      padding: 30px;
    }

    h2 {
      text-align: center;
      color: #1976d2;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      border-radius: 12px;
      overflow: hidden;
    }

    th, td {
      text-align: left;
      padding: 14px 16px;
    }

    th {
      background: #1976d2;
      color: white;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    tr:nth-child(even) {
      background: #f2f6fc;
    }

    tr:hover {
      background: #e8f0fe;
      transition: 0.2s;
    }

    td {
      color: #333;
    }

    .note {
      color: #555;
      font-style: italic;
    }

    .back-btn {
      display: inline-block;
      margin-top: 25px;
      background-color: #00b894;
      color: white;
      text-decoration: none;
      padding: 10px 25px;
      border-radius: 25px;
      transition: 0.3s;
    }

    .back-btn:hover {
      background-color: #019870;
    }

    .no-data {
      text-align: center;
      padding: 20px;
      color: #777;
      font-size: 16px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>📍 Child Tracking Dashboard</h2>
    
    <?php if ($result->num_rows > 0): ?>
    <table>
      <tr>
        <th>Child Name</th>
        <th>Location</th>
        <th>Last Update</th>
        <th>Note</th>
      </tr>
      <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['location']) ?></td>
        <td><?= htmlspecialchars($row['update_time']) ?></td>
        <td class="note"><?= htmlspecialchars($row['note']) ?></td>
      </tr>
      
      <?php endwhile; ?>
    </table>
    <?php else: ?>
      <p class="no-data">No tracking data found yet.</p>
    <?php endif; ?>

    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>

</body>
</html>
