<?php
include('includes/header.php');
include('includes/config.php');

// Fetch adoptions with related data
$query = "
    SELECT 
        a.id,
        c.name AS child_name,
        u.name AS adopter_name,
        u.email,
        a.status,
        a.adoption_date
    FROM adoptions a
    LEFT JOIN children c ON a.child_id = c.id
    LEFT JOIN users u ON a.adopter_id = u.id
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Adoptions</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Poppins', sans-serif;
    }
    .adoption-container {
      max-width: 1100px;
      margin: 50px auto;
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #00796b, #004d40);
      color: white;
      padding: 20px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .header h3 {
      margin: 0;
      font-weight: 600;
      letter-spacing: 0.5px;
    }
    table thead {
      background-color: #00796b;
      color: white;
    }
    table tbody tr:hover {
      background-color: #f1fdfb;
      transition: 0.3s;
    }
    .btn-view {
      background-color: #0d6efd;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      text-decoration: none;
    }
    .btn-approve {
      background-color: #198754;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      text-decoration: none;
    }
    .btn-reject {
      background-color: #dc3545;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      text-decoration: none;
    }
    .btn-view:hover { background-color: #0b5ed7; }
    .btn-approve:hover { background-color: #157347; }
    .btn-reject:hover { background-color: #bb2d3b; }
    .back-btn {
      background-color: #004d40;
      color: white;
      border-radius: 8px;
      padding: 8px 15px;
      text-decoration: none;
    }
    .back-btn:hover {
      background-color: #002f26;
      color: white;
    }
  </style>
</head>
<body>

<div class="adoption-container">
  <div class="header">
    <h3><i class="bi bi-people-fill"></i> Manage Adoptions</h3>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>

  <div class="table-responsive p-4">
    <table class="table table-bordered table-hover text-center align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Child Name</th>
          <th>Adopter Name</th>
          <th>Email</th>
          <th>Status</th>
          <th>Applied On</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['child_name']}</td>
                    <td>{$row['adopter_name']}</td>
                    <td>{$row['email']}</td>
                    <td>";
            
            // Display colored badges for status
            if ($row['status'] == 'Pending') {
              echo "<span class='badge bg-warning text-dark'>Pending</span>";
            } elseif ($row['status'] == 'Approved') {
              echo "<span class='badge bg-success'>Approved</span>";
            } elseif ($row['status'] == 'Rejected') {
              echo "<span class='badge bg-danger'>Rejected</span>";
            }

            echo "</td>
                    <td>{$row['adoption_date']}</td>
                    <td>";

            // Show actions based on status
            if ($row['status'] == 'Pending') {
              echo "
                <a href='update_adoption_status.php?id={$row['id']}&status=Approved' class='btn-approve btn-sm'>Approve</a>
                <a href='update_adoption_status.php?id={$row['id']}&status=Rejected' class='btn-reject btn-sm'>Reject</a>
              ";
            } else {
              echo "<a href='view_adoption.php?id={$row['id']}' class='btn-view btn-sm'>View</a>";
            }

            echo "</td>
                  </tr>";
          }
        } else {
          echo "<tr><td colspan='7'>No adoptions found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.js"></script>
</body>
</html>

<?php include('includes/footer.php'); ?>
