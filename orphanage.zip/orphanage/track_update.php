<?php
include 'includes/config.php';
include 'includes/auth_check.php';

$child_id = $_POST['child_id'];
$location = $_POST['location'];
$note = $_POST['note'];

$stmt = $conn->prepare("INSERT INTO child_tracking (child_id, location, note) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $child_id, $location, $note);
$stmt->execute();

header("Location: child_track.php");
exit();
?>
