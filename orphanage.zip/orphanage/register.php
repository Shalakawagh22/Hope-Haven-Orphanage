<?php
include 'includes/config.php';
include 'includes/header.php'; // keep same header as home page

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role']; // admin or user

    // Check if email already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $existingUser = $stmt->get_result()->fetch_assoc();

    if ($existingUser) {
        $error = "Email already registered!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);

        if ($stmt->execute()) {
            $success = "Registration successful! You can now log in.";
        } else {
            $error = "Error registering user!";
        }
    }
}
?>

<!-- ===== Register Page Content ===== -->
<div class="register-container">
    <div class="register-box">
        <h2>Create an Account</h2>
        <p class="subtitle">Join Hope Haven — donate, adopt, or volunteer!</p>

        <?php if (!empty($error)) echo "<p class='error-msg'>$error</p>"; ?>
        <?php if (!empty($success)) echo "<p class='success-msg'>$success</p>"; ?>

        <form method="POST" class="register-form">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>

            <label for="role">Register as:</label>
            <select name="role" id="role" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>

            <button type="submit" class="btn-submit">Register</button>
        </form>

        <p class="redirect-text">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>

<style>
/* ===== Register Page Styling ===== */
.register-container {
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #1e90ff, #4682b4);
    min-height: 90vh;
    padding: 30px;
}

.register-box {
    background: white;
    padding: 40px 50px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    max-width: 420px;
    width: 100%;
    text-align: center;
}

.register-box h2 {
    color: #ff7043;
    font-size: 28px;
    margin-bottom: 10px;
}

.subtitle {
    color: #555;
    font-size: 15px;
    margin-bottom: 20px;
}

.register-form input,
.register-form select {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 15px;
    outline: none;
    transition: border-color 0.3s;
}

.register-form input:focus,
.register-form select:focus {
    border-color: #ff7043;
}

.btn-submit {
    background-color: #ff7043;
    color: white;
    border: none;
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-submit:hover {
    background-color: #ff5722;
}

.redirect-text {
    margin-top: 15px;
    font-size: 14px;
}

.redirect-text a {
    color: #ff7043;
    text-decoration: none;
}

.error-msg {
    color: red;
    font-weight: bold;
    margin-bottom: 10px;
}

.success-msg {
    color: green;
    font-weight: bold;
    margin-bottom: 10px;
}
</style>

<?php include 'includes/footer.php'; // keep same footer ?>
