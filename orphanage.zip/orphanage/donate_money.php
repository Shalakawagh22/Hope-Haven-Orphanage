<?php
include 'includes/config.php';
include 'includes/header.php';

$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donor = trim($_POST['donor'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);
    $note = trim($_POST['note'] ?? '');

    if (!$donor || $amount <= 0) {
        $error = "Please provide a valid name and amount.";
    } else {
        $stmt = $conn->prepare("INSERT INTO donations_money (donor_name, email, amount, note) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssds', $donor, $email, $amount, $note);
        if ($stmt->execute()) {
            $success = "Thank you, " . htmlspecialchars($donor) . "! Your donation of ₹" . number_format($amount,2) . " has been recorded.";
        } else {
            $error = "Could not record donation. Try again.";
        }
        $stmt->close();
    }
}
?>

<div class="container form-container">
  <h2>Donate Money</h2>
  <?php if ($success) echo "<p class='success'>$success</p>"; ?>
  <?php if ($error) echo "<p class='error'>$error</p>"; ?>
  <form method="POST" class="donation-form">
    <input name="donor" placeholder="Your name" required>
    <input name="email" placeholder="Your email (optional)">
    <input name="amount" placeholder="Amount (₹)" required type="number" step="0.01" min="1">
    <input name="note" placeholder="Note (optional)">
    <button class="btn" type="submit">Donate</button>
  </form>
</div>

<?php include 'includes/footer.php'; ?>
