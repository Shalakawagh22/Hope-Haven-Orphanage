<?php
include("includes/config.php");
include("includes/auth_check.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$result = $conn->query("
    SELECT c.name AS child_name, t.location, t.note, t.update_time 
    FROM child_tracking t
    JOIN children c ON c.id = t.child_id
    ORDER BY t.update_time DESC
");
?>

<?php include("includes/header.php"); ?>

<div class="tracking-view">
  <h2>Child Tracking Updates</h2>
  <p class="subtitle">Below are the latest updates about children in our care.</p>
  <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>

  <table border="1" cellpadding="10" cellspacing="0">
    <tr>
      <th>Child Name</th>
      <th>Location</th>
      <th>Note</th>
      <th>Updated On</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= htmlspecialchars($row['child_name']) ?></td>
        <td><?= htmlspecialchars($row['location']) ?></td>
        <td><?= htmlspecialchars($row['note']) ?></td>
        <td><?= htmlspecialchars($row['update_time']) ?></td>
      </tr>
    <?php } ?>
  </table>
</div>

<?php include("includes/footer.php"); ?>

<style>
.tracking-view {
  text-align: center;
  margin: 80px auto;
  max-width: 900px;
  background: #fff;
  padding: 30px;
  border-radius: 16px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 25px;
}

th {
  background-color: #2a9d8f;
  color: white;
}

td, th {
  border: 1px solid #ccc;
  padding: 10px;
}
</style>
