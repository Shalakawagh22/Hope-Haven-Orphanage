<?php include('includes/config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Donate - Orphanage</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <h2>Donate Items or Money</h2>

  <form action="donate.php" method="POST" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" required><br><br>

    <label>Email:</label>
    <input type="email" name="email" required><br><br>

    <label>Donation Type:</label>
    <select name="type">
      <option value="money">Money</option>
      <option value="clothes">Clothes</option>
      <option value="food">Food</option>
      <option value="others">Others</option>
    </select><br><br>

    <label>Amount or Description:</label>
    <textarea name="details" placeholder="Enter details..."></textarea><br><br>

    <label>Upload Image (optional):</label>
    <input type="file" name="donation_image" accept="image/*"><br><br>

    <button type="submit" name="submit">Submit Donation</button>
  </form>

  <?php
  if (isset($_POST['submit'])) {
      $name = $_POST['name'];
      $email = $_POST['email'];
      $type = $_POST['type'];
      $details = $_POST['details'];

      // image upload
      $target_dir = "uploads/";
      $file_name = basename($_FILES["donation_image"]["name"]);
      $target_file = $target_dir . time() . "_" . $file_name;

      if (!empty($_FILES["donation_image"]["name"])) {
          move_uploaded_file($_FILES["donation_image"]["tmp_name"], $target_file);
      } else {
          $target_file = "";
      }

      $sql = "INSERT INTO donations (name, email, type, details, image, created_at)
              VALUES ('$name', '$email', '$type', '$details', '$target_file', NOW())";

      if ($conn->query($sql)) {
          echo "<p style='color:green;'>Donation submitted successfully!</p>";
      } else {
          echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
      }
  }
  ?>

  <hr>
  <h3>Recent Donations</h3>

  <div class="gallery">
    <?php
    $result = $conn->query("SELECT * FROM donations ORDER BY id DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<h4>{$row['name']} ({$row['type']})</h4>";
        if ($row['image']) {
            echo "<img src='{$row['image']}' width='200' height='150' alt='Donation Image'>";
        }
        echo "<p>{$row['details']}</p>";
        echo "</div>";
    }
    ?>
  </div>
</body>
</html>
