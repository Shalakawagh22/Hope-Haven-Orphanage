<?php
include('includes/header.php');
include('includes/config.php');

// Fetch users
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registered Users</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Poppins', sans-serif;
    }
    .user-table-container {
      max-width: 1100px;
      margin: 50px auto;
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    .user-table-header {
      background: linear-gradient(135deg, #009688, #00695c);
      color: white;
      padding: 20px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .user-table-header h3 {
      margin: 0;
      font-weight: 600;
      letter-spacing: 0.5px;
    }
    table thead {
      background-color: #009688;
      color: white;
    }
    table tbody tr:hover {
      background-color: #f1fdfb;
      transition: 0.3s;
    }
    .btn-delete {
      background-color: #dc3545;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      transition: 0.3s;
    }
    .btn-delete:hover {
      background-color: #c82333;
    }
    .back-btn {
      background-color: #00796b;
      color: white;
      border-radius: 8px;
      padding: 8px 15px;
      text-decoration: none;
    }
    .back-btn:hover {
      background-color: #004d40;
      color: white;
    }
  </style>
</head>
<body>

<div class="user-table-container">
  <div class="user-table-header">
    <h3><i class="bi bi-people-fill"></i> Registered Users</h3>
    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>

  <div class="table-responsive p-4">
    <table class="table table-bordered table-hover text-center align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Role</th>
          <th>Registered On</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['role']}</td>
                    <td>{$row['created_at']}</td>
                    <td>
                      <a href='delete_user.php?id={$row['id']}' class='btn-delete'>Delete</a>
                    </td>
                  </tr>";
          }
        } else {
          echo "<tr><td colspan='6'>No users found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.js"></script>
</body>
</html>

<?php include('includes/footer.php'); ?>
