<?php
include 'includes/config.php';
include 'includes/header.php';

$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (!$name || !$email || !$message) {
        $error = "Please complete all fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO contact_messages (user_name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param('sss', $name, $email, $message);
        if ($stmt->execute()) {
            $success = "Thank you, " . htmlspecialchars($name) . ". Your message has been sent.";
        } else {
            $error = "Something went wrong. Please try later.";
        }
        $stmt->close();
    }
}
?>

<div class="container form-container">
  <h2>Contact Us</h2>
  <?php if ($success) echo "<p class='success'>$success</p>"; ?>
  <?php if ($error) echo "<p class='error'>$error</p>"; ?>
  <form method="POST" class="contact-form">
    <input name="name" placeholder="Your name" required>
    <input name="email" placeholder="Your email" required type="email">
    <textarea name="message" placeholder="Your message" required></textarea>
    <button class="btn" type="submit">Send Message</button>
  </form>
</div>

<?php include 'includes/footer.php'; ?>
