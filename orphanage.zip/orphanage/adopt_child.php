<?php
// Include configuration and authentication check
include("includes/config.php");
include("includes/auth_check.php");

// Make sure session is active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check user role (only logged-in users can adopt)
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Adopt a Child</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body {
      background-color: #f7f9fa;
      font-family: Arial, sans-serif;
    }

    .adopt-container {
      max-width: 800px;
      margin: 100px auto; /* Adds space below the header */
      background: #fff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h3 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    form select {
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 16px;
    }

    form button {
      display: block;
      width: 100%;
      background-color: #2a9d8f;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: 0.3s;
    }

    form button:hover {
      background-color: #21867a;
    }

    .success-message {
      background-color: #e0f7e9;
      color: #2e7d32;
      border: 1px solid #81c784;
      padding: 10px;
      border-radius: 6px;
      text-align: center;
      margin-bottom: 20px;
      font-weight: 500;
    }
  </style>
</head>
<body>

<!-- ✅ Import header -->
<?php include("includes/header.php"); ?>

<div class="adopt-container">
  <?php
  // Handle form submission
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $child_id = $_POST['child_id'];
      $adopter_id = $_SESSION['user_id'];

      $stmt = $conn->prepare("INSERT INTO adoptions (child_id, adopter_id) VALUES (?, ?)");
      $stmt->bind_param("ii", $child_id, $adopter_id);
      $stmt->execute();

      echo "<div class='success-message'>🎉 Adoption request sent successfully!</div>";
  }

  // Fetch children from database
  $children = $conn->query("SELECT * FROM children WHERE status='Available'");
  ?>

  <form method="POST">
    <h3>Adopt a Child</h3>
    <select name="child_id" required>
      <?php while ($c = $children->fetch_assoc()) { ?>
        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= $c['age'] ?> yrs)</option>
      <?php } ?>
    </select>
    <button type="submit">Send Request</button>
  </form>
</div>

<!-- ✅ Import footer -->
<?php include("includes/footer.php"); ?>

</body>
</html>
