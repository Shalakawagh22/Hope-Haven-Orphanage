-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 07, 2025 at 01:24 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoptions`
--

DROP TABLE IF EXISTS `adoptions`;
CREATE TABLE IF NOT EXISTS `adoptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `child_id` int DEFAULT NULL,
  `adopter_id` int DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `adoption_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `child_id` (`child_id`),
  KEY `adopter_id` (`adopter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `adoptions`
--

INSERT INTO `adoptions` (`id`, `child_id`, `adopter_id`, `status`, `adoption_date`) VALUES
(9, 4, 3, 'Pending', '2025-11-07 13:01:31'),
(8, 3, 3, 'Pending', '2025-11-07 12:38:24'),
(7, 2, 3, 'Pending', '2025-11-07 12:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

DROP TABLE IF EXISTS `children`;
CREATE TABLE IF NOT EXISTS `children` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `description` text,
  `status` enum('Available','Adopted') DEFAULT 'Available',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `children`
--

INSERT INTO `children` (`id`, `name`, `age`, `gender`, `description`, `status`) VALUES
(2, 'Sejal Shirke', 10, 'Female', 'Height 3\r\nAge:10\r\nFair', 'Available'),
(3, 'Sakshi lonare', 12, 'Female', '', 'Available'),
(4, 'Rohit Patil', 8, 'Male', 'Fair\r\nHeight:4\r\nWeight:23', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `child_tracking`
--

DROP TABLE IF EXISTS `child_tracking`;
CREATE TABLE IF NOT EXISTS `child_tracking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `child_id` int DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `note` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `child_id` (`child_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `child_tracking`
--

INSERT INTO `child_tracking` (`id`, `child_id`, `location`, `note`, `updated_at`, `update_time`) VALUES
(6, 4, 'mumbai', '', '2025-11-07 13:02:39', '2025-11-07 18:32:39'),
(5, 2, 'mumbai', '', '2025-11-07 12:45:43', '2025-11-07 18:15:43');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `user_name`, `email`, `message`, `created_at`) VALUES
(2, 'Shalaka Sharad Wagh', 'shalakawagh22@gmail.com', 'Let me know about the adoption!!', '2025-11-07 12:34:40'),
(3, 'Shalaka Sharad Wagh', 'shalakawagh22@gmail.com', 'nhbofj;fn\'kwqjfiof', '2025-11-07 13:02:06');

-- --------------------------------------------------------

--
-- Table structure for table `donations_clothes`
--

DROP TABLE IF EXISTS `donations_clothes`;
CREATE TABLE IF NOT EXISTS `donations_clothes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `donor_name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `donations_clothes`
--

INSERT INTO `donations_clothes` (`id`, `donor_name`, `email`, `description`, `image_path`, `created_at`) VALUES
(6, 'shalaka', 'shalakawagh22@gmail.com', 'Tshirts', 'uploads/clothes/cloth_690dedc7288382.16368898.png', '2025-11-07 13:01:59'),
(5, 'shalaka', 'shalakawagh22@gmail.com', 'Tshirts', 'uploads/clothes/cloth_690de74ff23753.66251661.png', '2025-11-07 12:34:23');

-- --------------------------------------------------------

--
-- Table structure for table `donations_money`
--

DROP TABLE IF EXISTS `donations_money`;
CREATE TABLE IF NOT EXISTS `donations_money` (
  `id` int NOT NULL AUTO_INCREMENT,
  `donor_name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `donations_money`
--

INSERT INTO `donations_money` (`id`, `donor_name`, `email`, `amount`, `note`, `created_at`) VALUES
(6, 'shalaka', 'shalakawagh22@gmail.com', 60000.00, 'Donation for Education', '2025-11-07 13:01:47'),
(5, 'shalaka', 'shalakawagh22@gmail.com', 20000.00, 'Donation for Education', '2025-11-07 12:34:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `reset_token`, `token_expiry`) VALUES
(3, 'shalaka', 'shalakawagh22@gmail.com', '$2y$10$6YTdwPGO9Em05GlXXT2a/uv/KyPeVxTQoTo6Uu//fA/5gGZacXnkC', 'user', '2025-11-07 12:33:20', 'f1336860757f60173a8dc6eaeb23d0b7', '2025-11-07 13:30:56'),
(4, 'admin', 'admin@gmail.com', '$2y$10$iFMUwBcK5cUDubqesfJCxus4o4S.z5MCfQHDNFiO4sIKPxiMY5iT6', 'admin', '2025-11-07 12:35:47', NULL, NULL),
(5, 'adminshalaka', 'adminshalaka@gmail.com', '$2y$10$8cRVVMDzgSQuZapWiTIKS.u.MdblNh8HwRPsn6a/00G9/W./dYbHS', 'admin', '2025-11-07 12:59:25', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
