<?php
include 'includes/config.php';
include 'includes/auth_check.php';

$child_id = $_POST['child_id'];
$user_id = $_SESSION['user_id'];

// Update status and record adoption
$stmt1 = $conn->prepare("UPDATE children SET status='adopted' WHERE id=?");
$stmt1->bind_param("i", $child_id);
$stmt1->execute();

$stmt2 = $conn->prepare("INSERT INTO adoptions (child_id, user_id) VALUES (?, ?)");
$stmt2->bind_param("ii", $child_id, $user_id);
$stmt2->execute();

echo "<h3>🎉 Congratulations! You've successfully initiated adoption.</h3>
      <p>Our team will contact you for verification.</p>
      <a href='index.php'>Back to Home</a>";
?>
