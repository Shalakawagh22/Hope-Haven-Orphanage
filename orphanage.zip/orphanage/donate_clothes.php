<?php
include 'includes/config.php';
include 'includes/header.php';



$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donor = trim($_POST['donor'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $description = trim($_POST['description'] ?? '');

    $image_path = null;

    // Image upload section
    if (!empty($_FILES['image']['name'])) {
        $allowed = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
        $file_type = $_FILES['image']['type'];
        $file_size = $_FILES['image']['size'];

        if (in_array($file_type, $allowed) && $file_size <= 2 * 1024 * 1024) {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid('cloth_', true) . '.' . $ext;
            $upload_dir = 'uploads/clothes/';

            // Ensure directory exists
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $dest = $upload_dir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $image_path = $dest;
            } else {
                $error = "Failed to upload image. Please check folder permissions.";
            }
        } else {
            $error = "Invalid image file. Only png/jpg/gif allowed, and ≤2MB.";
        }
    }

    if (!$donor) $error = $error ?: "Please enter your name.";

    if (!$error) {
        $stmt = $conn->prepare("INSERT INTO donations_clothes (donor_name, email, description, image_path) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssss', $donor, $email, $description, $image_path);

        if ($stmt->execute()) {
            $success = "🎉 Thank you, " . htmlspecialchars($donor) . "! Your clothes donation is recorded successfully.";
        } else {
            $error = "Database error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<div class="container form-container">
  <h2>Donate Clothes</h2>
  <?php if ($success) echo "<p class='success'>$success</p>"; ?>
  <?php if ($error) echo "<p class='error'>$error</p>"; ?>
  
  <form method="POST" enctype="multipart/form-data" class="donation-form">
    <input name="donor" placeholder="Your name" required>
    <input name="email" type="email" placeholder="Your email (optional)">
    <input name="description" placeholder="What items are you donating?">
    
    <label class="file-label">Attach image (optional)
      <input type="file" name="image" accept="image/*">
    </label>
    
    <button class="btn" type="submit">Donate Clothes</button>
  </form>
</div>


<?php include 'includes/footer.php'; ?>
