<?php
// view_adoption.php
include('includes/config.php');
include('includes/auth_check.php'); // ensures admin
include('includes/header.php');

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header("Location: manage_adoption.php");
    exit;
}

// Fetch adoption with joined info
$sql = "
  SELECT a.id, a.status, a.adoption_date,
         c.name AS child_name,
         u.name AS adopter_name, u.email
  FROM adoptions a
  LEFT JOIN children c ON a.child_id = c.id
  LEFT JOIN users u ON a.adopter_id = u.id
  WHERE a.id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$adoption = $result->fetch_assoc();
$stmt->close();

if (!$adoption) {
    echo "<div class='container mt-5'><div class='alert alert-warning'>Adoption not found.</div></div>";
    include('includes/footer.php');
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>View Adoption #<?= htmlspecialchars($adoption['id']) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .card-centered { max-width:900px; margin:40px auto; }
    .status-pill { padding:6px 12px; border-radius:20px; color:#fff; font-weight:600; }
    .status-pending { background:#ff9800; }
    .status-approved { background:#2e7d32; }
    .status-rejected { background:#c62828; }
    .actions a, .actions form { display:inline-block; margin-right:8px; }
  </style>
</head>
<body>

<div class="container card-centered">
  <div class="card shadow-sm">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
          <h3 class="card-title mb-1">Adoption Request — #<?= htmlspecialchars($adoption['id']) ?></h3>
          <small class="text-muted">Applied on: <?= htmlspecialchars($adoption['adoption_date']) ?></small>
        </div>
        <div>
          <?php
            $st = strtolower($adoption['status']);
            $cls = $st === 'approved' ? 'status-approved' : ($st === 'rejected' ? 'status-rejected' : 'status-pending');
          ?>
          <span class="status-pill <?= $cls ?>"><?= htmlspecialchars($adoption['status']) ?></span>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-6">
          <h6 class="text-secondary mb-2">Child Details</h6>
          <p class="mb-1"><strong>Name:</strong> <?= htmlspecialchars($adoption['child_name'] ?: '—') ?></p>
        </div>

        <div class="col-md-6">
          <h6 class="text-secondary mb-2">Adopter Details</h6>
          <p class="mb-1"><strong>Name:</strong> <?= htmlspecialchars($adoption['adopter_name'] ?: '—') ?></p>
          <p class="mb-1"><strong>Email:</strong> <?= htmlspecialchars($adoption['email'] ?: '—') ?></p>
        </div>
      </div>

      <hr>

      <div class="actions">
        <!-- Approve / Reject forms (POST) -->
        <?php if ($adoption['status'] !== 'Approved'): ?>
          <form method="POST" action="admin_dashboard.php" style="display:inline;">
            <input type="hidden" name="id" value="<?= $adoption['id'] ?>">
            <input type="hidden" name="status" value="Approved">
            <button class="btn btn-success btn-sm" type="submit" onclick="return confirm('Approve this adoption?')">Approve</button>
          </form>
        <?php endif; ?>

        <?php if ($adoption['status'] !== 'Rejected'): ?>
          <form method="POST" action="admin_dashboard.php" style="display:inline;">
            <input type="hidden" name="id" value="<?= $adoption['id'] ?>">
            <input type="hidden" name="status" value="Rejected">
            <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Reject this adoption?')">Reject</button>
          </form>
        <?php endif; ?>

       

        <a href="manage_adoption.php" class="btn btn-link btn-sm">← Back</a>
      </div>

    </div>
  </div>
</div>

</body>
</html>

<?php include('includes/footer.php'); ?>
