<?php
$servername = "localhost";
$username = "root"; // default for WAMP
$password = ""; // keep empty unless you set one
$dbname = "orphanage_db"; // ✅ your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
