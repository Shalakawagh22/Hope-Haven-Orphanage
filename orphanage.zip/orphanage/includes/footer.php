<?php
// footer.php — include at bottom
?>
</main>
<footer class="site-footer">
  <div class="container">
    <p>© <?=date('Y')?> Hope Haven | Designed by Shalaka Wagh</p>
  </div>
</footer>
<script src="js/script.js"></script>
</body>
</html>
