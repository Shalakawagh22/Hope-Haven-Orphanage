<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hope Haven - Orphanage</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container header-inner">
    <div class="brand">
      <img src="images/logo.png" alt="logo" class="logo">
      <h1>Hope Haven</h1>
    </div>

    <nav class="nav">
      <a href="index.php">Home</a>
      <a href="about.php">About</a>
      <a href="donate_money.php">Donate Money</a>
      <a href="donate_clothes.php">Donate Clothes</a>
      <a href="contact.php">Contact</a>
      
      <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_name'])): ?>
        <span class="username">Hi, <?= htmlspecialchars($_SESSION['user_name']) ?></span>
        <a href="logout.php" class="btn small">Logout</a>
      <?php else: ?>
        <a href="login.php" class="btn small">Login</a>
        <a href="register.php" class="btn small">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<main style="margin-top: 40px;">
