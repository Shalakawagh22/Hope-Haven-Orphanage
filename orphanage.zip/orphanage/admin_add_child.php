<?php
include 'includes/config.php';
include 'includes/auth_check.php'; // only admin in real case

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $desc = $_POST['description'];

    $image_path = null;
    if (!empty($_FILES['image']['name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('child_', true) . '.' . $ext;
        $upload_dir = 'uploads/children/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $dest = $upload_dir . $filename;
        move_uploaded_file($_FILES['image']['tmp_name'], $dest);
        $image_path = $dest;
    }

    $stmt = $conn->prepare("INSERT INTO children (name, age, gender, description, image_path) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sisss", $name, $age, $gender, $desc, $image_path);
    if ($stmt->execute()) $success = "Child added successfully.";
    else $error = "Error: " . $stmt->error;
}
?>

<form method="POST" enctype="multipart/form-data">
  <h3>Add Child for Adoption</h3>
  <?php if($success) echo "<p style='color:green'>$success</p>"; ?>
  <?php if($error) echo "<p style='color:red'>$error</p>"; ?>
  <input type="text" name="name" placeholder="Child Name" required><br>
  <input type="number" name="age" placeholder="Age" required><br>
  <select name="gender">
    <option value="Male">Male</option>
    <option value="Female">Female</option>
  </select><br>
  <textarea name="description" placeholder="Child background info"></textarea><br>
  <input type="file" name="image" accept="image/*"><br>
  <button type="submit">Add Child</button>
</form>
