<?php
include 'includes/config.php';
include 'includes/header.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// After verifying login credentials successfully
 // optional



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && ($password === $user['password'] || password_verify($password, $user['password']))) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['name'] = $user['name'];

        if ($user['role'] === 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            header("Location: index.php");
        }
        exit;
    } else {
        $error = "Invalid email or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hope Haven - Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background: linear-gradient(120deg, #2196f3, #0d47a1);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            
        }

        /* Centered Login Section */
        .login-section {
                   
  background: white;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
  width: 400px;
  margin: 120px auto 100px auto; /* same spacing as register */
  margin-top: calc(8rem + 20px);

}
        

        .login-box {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 40px 50px;
            border-radius: 12px;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
        }

        .login-box h2 {
            color: #ff7043;
            margin-bottom: 20px;
        }

        .login-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
            outline: none;
        }

        .login-box button {
            width: 100%;
            padding: 10px;
            background-color: #ff7043;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            
        }

        .login-box button:hover {
            background-color: #f4511e;
        }

        .login-box p {
            margin-top: 10px;
            font-size: 14px;
        }

        .login-box a {
            color: #ff7043;
            text-decoration: none;
        }

        .login-box a:hover {
            text-decoration: underline;
        }

        .error-msg {
            color: red;
            font-weight: 500;
            margin-bottom: 10px;
        }

        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 14px;
        }



        @media (max-width: 768px) {
            .login-box {
                width: 90%;
                padding: 30px 20px;
            }
        }
        

         
    </style>
</head>
<body>

    <!-- Login Section -->
    <div class="login-section">
        <form method="POST" class="login-box">
            <h2>Login to Your Account</h2>
            <?php if (!empty($error)) echo "<p class='error-msg'>$error</p>"; ?>

            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <button type="submit">Login</button>

            <p>Don't have an account? <a href="register.php">Register here</a></p>
            <p><a href="forgot_password.php">Forgot Password?</a></p>
        </form>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

</body>
</html>
