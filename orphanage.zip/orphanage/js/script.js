// small convenience: fade in shims already done by CSS classes above
document.addEventListener('DOMContentLoaded', () => {
  console.log('Hope Haven loaded');
});
