<?php
include("includes/config.php");
include("includes/auth_check.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $child_id = $_POST['child_id'];
    $adopter_name = $_POST['adopter_name'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];

    $sql = "INSERT INTO adoptions (child_id, adopter_name, contact, address, status)
            VALUES ('$child_id', '$adopter_name', '$contact', '$address', 'pending')";

    if ($conn->query($sql)) {
        echo "<script>alert('Adoption request submitted successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
