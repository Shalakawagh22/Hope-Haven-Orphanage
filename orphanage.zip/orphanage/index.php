<?php include 'includes/header.php'; ?>
<?php include 'includes/config.php'; ?>

<!-- Hero Section -->
<section class="hero">
  <div class="hero-content">
    <h1>Welcome to Hope Haven Orphanage</h1>
    <p>Together we can make a difference — Donate, Adopt, or Support today!</p>
    <a href="donate_money.php" class="btn">Donate Now</a>
  </div>

  <!-- Added Animated Image -->
  <div class="hero-image">
    <img src="images/kids.jpg" alt="Hope Haven Children">
  </div>
</section>


<!-- About Section -->
<section class="about">
  <h2>About Us</h2>
  <p>We are a non-profit organization dedicated to providing shelter, education, and emotional care for orphaned children. 
  Your small contribution can bring a big smile to their faces.</p>
  <a href="about.php" class="btn">About Us!</a>
</section>

<!-- Adoption Section -->
<section class="adoption">
  <h2>Adopt a Child</h2>
  <p>Provide a child with a loving home. You can view available children and apply for adoption.</p>
  <a href="adopt_child.php" class="btn">Start Adoption</a>
</section>

<!-- Child Tracking Section -->
<section class="tracking">
  <h2>Child Tracking</h2>
  <p>Our transparent tracking system allows sponsors and donors to view the latest updates of the children they support.</p>

  <div class="view-tracking">
    <a href="child_track.php" class="btn-secondary">View All Tracking Updates</a>
  </div>
</section>

<!-- Contact Section -->
<section class="contact">
  <h2>Get In Touch</h2>
  <p>Have questions or want to volunteer? Reach out to us anytime.</p>
  <a href="contact.php" class="btn">Contact Us</a>
</section>

<?php include 'includes/footer.php'; ?>

<!-- Add this CSS inside your style.css file -->
<style>
  .hero {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
  }

  .hero-image {
    margin-top: 30px;
    animation: float 3s ease-in-out infinite;
  }

  .hero-image img {
    max-width: 350px;
    width: 100%;
    border-radius: 20px;
    box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
  }

  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-15px); }
    100% { transform: translateY(0px); }
  }
</style>
