<?php
include('includes/config.php');

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = intval($_GET['id']);
    $status = $_GET['status'];

    if (in_array($status, ['Approved', 'Rejected'])) {
        $query = "UPDATE adoptions SET status = '$status' WHERE id = $id";
        mysqli_query($conn, $query);
    }
}

header("Location: manage_adoption.php");
exit();
?>
