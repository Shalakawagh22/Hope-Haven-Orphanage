<?php include('includes/header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Hope Haven</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    /* Hero Section */
    .hero-section {
      background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), 
                  url('images/orphanage_banner.jpg') center/cover no-repeat;
      color: white;
      text-align: center;
      padding: 120px 20px;
      border-radius: 0 0 30px 30px;
      animation: fadeIn 1.5s ease;
    }
    .hero-section h1 {
      font-size: 3rem;
      font-weight: bold;
    }
    .hero-section p {
      font-size: 1.2rem;
      margin-top: 15px;
      max-width: 700px;
      margin-left: auto;
      margin-right: auto;
    }

    /* About Content */
    .about-content {
      max-width: 1000px;
      margin: 50px auto;
      padding: 20px;
      text-align: center;
      animation: slideUp 1.5s ease;
    }
    .about-content h2 {
      color: #ff6b3d;
      font-size: 2rem;
      margin-bottom: 15px;
    }
    .about-content p {
      font-size: 1.1rem;
      line-height: 1.8;
      color: #444;
    }

    /* Our Values Section */
    .values-section {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 25px;
      padding: 50px 20px;
      background: #fff6f2;
      border-radius: 20px;
      margin: 40px auto;
      max-width: 1100px;
    }
    .value-card {
      background: white;
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      text-align: center;
    }
    .value-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    .value-card i {
      font-size: 2.5rem;
      color: #ff6b3d;
      margin-bottom: 15px;
    }
    .value-card h3 {
      font-size: 1.3rem;
      margin-bottom: 10px;
    }
    .value-card p {
      font-size: 1rem;
      color: #555;
    }

    /* Animations */
    @keyframes fadeIn {
      from {opacity: 0;}
      to {opacity: 1;}
    }
    @keyframes slideUp {
      from {transform: translateY(30px); opacity: 0;}
      to {transform: translateY(0); opacity: 1;}
    }

    /* Footer */
    footer {
      margin-top: 50px;
      text-align: center;
      padding: 20px;
      color: #555;
      font-size: 0.9rem;
    }
  </style>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

  <div class="hero-section">
    <h1>About Hope Haven</h1>
    <p>Building a world where every child feels loved, valued, and supported to grow into their brightest self.</p>
  </div>

  <div class="about-content">
    <h2>Who We Are</h2>
    <p>Hope Haven is a non-profit organization dedicated to providing a safe and loving environment for orphans and abandoned children. We strive to ensure that every child has access to education, healthcare, and emotional support to lead a fulfilling life.</p>
  </div>

  <div class="about-content">
    <h2>Our Vision</h2>
    <p>We envision a world where no child feels alone, where every orphan receives the opportunity to dream, grow, and succeed with dignity and hope.</p>
  </div>

  <div class="values-section">
    <div class="value-card">
      <i class="fas fa-heart"></i>
      <h3>Compassion</h3>
      <p>We lead with kindness, love, and care for every child and community we serve.</p>
    </div>
    <div class="value-card">
      <i class="fas fa-book-open"></i>
      <h3>Education</h3>
      <p>We empower children through quality education to help them achieve their dreams.</p>
    </div>
    <div class="value-card">
      <i class="fas fa-hands-helping"></i>
      <h3>Empowerment</h3>
      <p>We aim to create confident, independent individuals who can make a difference.</p>
    </div>
    <div class="value-card">
      <i class="fas fa-users"></i>
      <h3>Community</h3>
      <p>We believe in the strength of community to support and uplift one another.</p>
    </div>
  </div>

 

</body>
</html>
<?php include('includes/footer.php'); ?>
