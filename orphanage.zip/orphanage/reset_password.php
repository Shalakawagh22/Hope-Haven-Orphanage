<?php
session_start();
include 'includes/config.php';
include 'includes/header.php';

$token = $_GET['token'] ?? '';
$message = '';

if (!empty($token)) {
    $query = "SELECT * FROM users WHERE reset_token = ? AND token_expiry > NOW()";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        $message = "<p style='color:red;'>Invalid or expired token.</p>";
    }
} else {
    $message = "<p style='color:red;'>Invalid link.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>
<link rel="stylesheet" href="css/style.css">
<style>
.reset-container{display:flex;justify-content:center;align-items:center;min-height:70vh;}
.reset-box{background:#fff;padding:30px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.1);width:350px;text-align:center;}
.reset-box h2{color:#ff7043;}
.reset-box input{width:100%;padding:10px;margin:10px 0;border-radius:8px;border:1px solid #ccc;}
.reset-box button{background:#ff7043;color:white;padding:10px;width:100%;border:none;border-radius:8px;cursor:pointer;}
.reset-box button:hover{background:#ff5722;}
</style>
</head>
<body>

<div class="reset-container">
<div class="reset-box">
<h2>Reset Password</h2>
<?php if (empty($message)): ?>
<form method="POST" action="update_password.php">
    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
    <input type="password" name="new_password" placeholder="Enter new password" required>
    <button type="submit">Update Password</button>
    
</form>
<?php else: ?>
<?= $message; ?>
<?php endif; ?>
</div>
<a href="login.php" class="back-btn"><br><br><br><br><br><br><br> <-Back to Login</a>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>
