<?php
include("includes/config.php");
include("includes/auth_check.php");

// Start session if not already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Allow only admins
if ($_SESSION['role'] !== 'admin') {
    header("Location: view_child_tracking.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $child_id = $_POST['child_id'];
    $location = $_POST['location'];
    $note = $_POST['note'];

    $stmt = $conn->prepare("INSERT INTO child_tracking (child_id, location, note, update_time) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $child_id, $location, $note);
    $stmt->execute();

    echo "<p style='color:green;text-align:center;'>✅ Tracking updated successfully!</p>";
}

$children = $conn->query("SELECT id, name FROM children");
?>

<?php include("includes/header.php"); ?>

<div class="tracking-container">
  <h2>Child Tracking</h2>
  <p class="subtitle">Our transparent tracking system allows sponsors and donors to view the latest updates of the children they support.</p>
  <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  <form method="POST" class="tracking-form">
    <select name="child_id" required>
      <option value="">Select Child</option>
      <?php while ($child = $children->fetch_assoc()) { ?>
        <option value="<?= $child['id'] ?>"><?= htmlspecialchars($child['name']) ?></option>
      <?php } ?>
    </select>

    <input type="text" name="location" placeholder="Enter current location" required>
    <textarea name="note" placeholder="Add a note (optional)"></textarea>

    <button type="submit" class="update-btn">Update Tracking</button>
  </form>

  <a href="view_child_tracking.php" class="view-btn">View All Tracking Updates</a>
  
</div>

<?php include("includes/footer.php"); ?>

<style>
.tracking-container {
  text-align: center;
  margin: 100px auto;
  max-width: 600px;
  background: #fff;
  padding: 30px;
  border-radius: 16px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.subtitle {
  color: #555;
  margin-bottom: 25px;
}

.tracking-form select,
.tracking-form input,
.tracking-form textarea {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 8px;
  border: 1px solid #ccc;
}

.update-btn {
  background-color: #00b894;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 25px;
  cursor: pointer;
}

.update-btn:hover {
  background-color: #019870;
}

.view-btn {
  display: inline-block;
  margin-top: 20px;
  background-color: #1976d2;
  color: white;
  text-decoration: none;
  padding: 10px 25px;
  border-radius: 25px;
}

.view-btn:hover {
  background-color: #0d47a1;
}
</style>
