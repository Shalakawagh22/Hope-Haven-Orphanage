<?php
include('includes/config.php');
include('includes/header.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $age = trim($_POST['age']);
    $gender = trim($_POST['gender']);
    $description = trim($_POST['description']);

    if ($name && $age && $gender) {
        $stmt = $conn->prepare("INSERT INTO children (name, age, gender, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siss", $name, $age, $gender, $description);
        if ($stmt->execute()) {
            echo "<div class='alert alert-success text-center mt-3'>✅ Child added successfully!</div>";
        } else {
            echo "<div class='alert alert-danger text-center mt-3'>❌ Error adding child.</div>";
        }
        $stmt->close();
    } else {
        echo "<div class='alert alert-warning text-center mt-3'>⚠️ Please fill in all required fields.</div>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add a Child</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f5f7fa;
      font-family: 'Poppins', sans-serif;
    }
    .form-container {
      max-width: 600px;
      margin: 60px auto;
      background: #fff;
      padding: 30px 40px;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .btn-custom {
      background: #007bff;
      color: #fff;
      font-weight: 500;
      border-radius: 8px;
    }
    .btn-custom:hover {
      background: #0056b3;
    }
    h2 {
      text-align: center;
      color: #333;
      font-weight: 600;
      margin-bottom: 25px;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>Add a Child</h2>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Child Name</label>
      <input type="text" name="name" class="form-control" placeholder="Enter child's full name" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Age</label>
      <input type="number" name="age" class="form-control" placeholder="Enter age" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Gender</label>
      <select name="gender" class="form-select" required>
        <option value="">Select Gender</option>
        <option value="Male">👦 Male</option>
        <option value="Female">👧 Female</option>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="3" placeholder="Write a short description or background"></textarea>
    </div>

    <div class="text-center">
      <button type="submit" class="btn btn-custom px-4">Add Child</button>
      <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
    </div>
  </form>
</div>

</body>
</html>

<?php include('includes/footer.php'); ?>
